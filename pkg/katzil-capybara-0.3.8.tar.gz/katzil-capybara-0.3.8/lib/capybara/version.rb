module Capybara
  VERSION = '0.3.8'
end
